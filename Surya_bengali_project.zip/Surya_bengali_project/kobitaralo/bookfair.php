<!DOCTYPE html>
 <html lang="en">
 <head>
     <style>
     #spl {
  
  border:2px solid #fff;
  background: url(img/tiger.png) no-repeat;
  -moz-box-shadow: 10px 10px 5px #ccc;
  -webkit-box-shadow: 10px 10px 5px #ccc;
  box-shadow: 10px 10px 5px #ccc;
  -moz-border-radius:25px;
  -webkit-border-radius:25px;
  border-radius:25px;
}
</style>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title> বইমেলা সংখ্যা</title>
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
     <script src="https://kit.fontawesome.com/yourcode.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="../lib/w3.css">
     <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
     <link rel="stylesheet" href="css/navbar.css">
     <link rel="stylesheet" href="css/card.css">
     <link rel="stylesheet" href="css/signin.css">
     <link rel="stylesheet" href="css/footer.css">
     <link rel="stylesheet" href="css/dropdown.css">
     <link rel="stylesheet" href="css/popup.css">


 </head>
 <style>




 </style>
 <body  style=" background-image: url('img/b.jpg');
 background-size: cover;overflow-x: hidden;">
  <button onclick="topFunction()" id="myBtn" title="Go to top" style="color: white;"><i class="fa fa-arrow-up" aria-hidden="true"></i></button>

 
<div style="margin-left: 25px; margin-top :10px;">
        <center>
          <a href="index.php"class="active" style="background-color: transparent;"><img id="spl" src="img/KOsitebanne3r.png" height="auto" width="80%" ></a>

         
          <div id="mySidenav" class="sidenav" >
            <a href="javascript:void(0)" class="closebtn" onclick="CloseNav()">&times;</a>
          
            <a href="#" class=" nav-link " style="font-size: 16px;"><strong>আত্মপ্রকাশ সংখ্যা</strong></a> </li>
            <a href="bookfair.php" class= "nav-link"style="font-size: 16px;"><strong>বইমেলা সংখ্যা – ২০২০</strong></a> </li>
            <a href="sompadok.php" class="nav-link"style="font-size: 16px;"><strong>সম্পাদকীয়</strong></a></li>
            <a href="ahoron.php" class=" nav-link"style="font-size: 16px;" ><strong>আহরণ</strong></a></li>
            <a href="rupantor.php" class="nav-link "style="font-size: 16px;"><strong>রূপান্তর</strong></a></li>
            <a href="kandari.php " class=" nav-link "style="font-size: 16px;"><strong>কান্ডারী</strong></a></li>
            <a href="pothikrit.php" class=" nav-link "style="font-size: 16px;"><strong>পথিকৃৎ</strong></a></li>
            <a href="notundisha.php" class=" nav-link "style="font-size: 16px;"><strong>নতুন দিশা</strong></a></li>
            
            <a href="onnovubhan.php " class=" nav-link "style="font-size: 16px;"><strong>অন্যভুবন</strong></a></li>
            <a href="protibimbo.php" class=" nav-link "style="font-size: 16px;"><strong>প্রতিবিম্ব</strong></a></li>
             
       </div>

      <div class="ex1" style="float: right;">
         <span style="font-size:20px;cursor:pointer;" onclick="OpenNav()"><strong>Menu</strong></span>
          <a class="nav-item nav-link" style="color:black;margin-top: 10px;" href="signin.php" >
            <i class="w3-jumbo w3-spin  fa fa-user-circle fa-2x" aria-hidden="true" font-size="20px" ></i></a>
      </div>
      </div>        
<br>

<h2 style="display:inline;text-shadow: 2px 2px grey;">&nbsp;&nbsp;<strong>বইমেলা সংখ্যা</strong></h2>&nbsp;&nbsp;
<img src="img/zs.png" style="display: inline; width: 90px; height: 70px; margin-bottom: 5px;">
<div class= "container" style="padding: 20px 30px; word-spacing: 1em;">
  <div class="p1" style="background-color: black;
  margin: 20px;
  color: white;
  font-family: sans-serif;
  font-weight: 15px;
  width: 80%px;
  border: 5px red solid;
  padding-left:  10px;
  opacity: 90%;
  border-width: 13px;
  border-style: dashed;
  border-color: green;
  
  margin-top: 20px;
  margin-left: 50px;
  margin-bottom: 20px;
  
  text-transform: uppercase;">

    
<p> <strong style="text-align: center;">প্রথম বর্ষ । দ্বিতীয় সংখ্যা । জানুয়ারী ২০২০। ত্রিশ টাকা  <br>     Issue-I Vol-II, January 2020। Rs 30/-</strong><br><br>

 

      <h3 style="color: red; text-align: center;"><ul>ক  ল ম  চি</ul></h3>
      
       
      
      <h4 style="color: violet;">আহরণ</h4><br><br>
      
       
      
      <h5 style="color: yellow;">ভূর্জ্যপত্র</h5>
      
      <h6>যতীন্দ্রমোহন বাগচীঃ এক পৃথক স্বর <br>চয়ন সমাদ্দার
      </6>



      <h5 style="color: yellow;">স্বকাল দর্পণ</h5>

      <h6>
        নির্বাণজাত কলম ঃ অজিতেশ নাগ 
      </h6><br><br><br><br>
      


      <h4 style="color:violet;"> রূপান্তর
      </h4>

      <h6 >
        বাহাদুর শা জাফরের কবিতা <br>ভাষান্তরঃ শ্রীমন্ত সেন<br>উইলিয়াম ফ্রান্সিস বুরদোলিনের কবিতা<br>ভাষান্তরঃ ইন্দ্রাণী ঘোষ <br>  মারিও বেনেদেত্তির কবিতা <br>ভাষান্তরঃ শর্বরী গরাই
      </h6><br><br><br>


      <h4 style="color:violet;"> কান্ডারী
      </h4>
      <h6 >
        বৈজয়ন্ত রাহা।। নারায়ণ বিশ্বাস।। পিনাকী দত্তগুপ্ত।। রাহুল গুহ।। চয়ন সমাদ্দার।। নন্দিনী সেনগুপ্ত।। কাকলি দাশ ব্যানার্জী।। কৌশিক চক্রবর্তী।।
      </h6><br><br><br>

      <h4 style="color:violet;"> পথিকৃৎ
      </h4>

      <h6 >
        কমল দে সিকদার।। কৃষ্ণা বসু।। দীপক লাহিড়ী ।। রাণা চট্টোপাধ্যায় ।। সুভদ্রা ভট্টাচার্য।। শ্যামল মুখোপাধ্যায়।। নৃপেন চক্রবর্তী ।। কমল মুখোপাধ্যায়।। অরুণাচল দত্ত চৌধুরী।। ভারতী বন্দ্যোপাধ্যায়।। সৈয়দ হাসমত জালাল।। চৈতালী চট্টোপাধ্যায়।। ব্রত চক্রবর্তী।।</h6><br><br><br><br>

        
      <h4 style="color:violet;"> নতুন দিশা
      </h4>

      <h6 >বিনায়ক বন্দ্যোপাধায়।। পার্থজিৎ চন্দ।। তৈমুর খান।। ভগীরথ সর্দার।। সুশান্ত ভট্টাচার্য।। অনিরুদ্ধ সুব্রত।। জয়ন্ত চট্টোপাধ্যায়।। বিকাশরঞ্জন হালদার।। শর্মিষ্ঠা ঘোষ।। প্রবাল বসু।। বর্ণালী মুখোপাধ্যায়।। বব।। চিরন্তন ব্যানার্জী।। সুনন্দা হালদার।। সুমনা ভট্টাচার্য।। রথীন মন্ডল।। অনুপ রায়।। শৌভিক গাঙ্গুলী।। রাজীব পাল।। পিয়াংকী মুখার্জী।। শুভময় ঘোষ।। তমোঘ্ন চট্টোপাধ্যায়।। সোমনাথ বেনিয়া।। প্রত্যুষ কর্মকার।। সঞ্জয় চক্রবর্তী।। দিবাকর মন্ডল।। সৌরভ বটব্যাল।। সুমন দিন্দা।। মারুফ আহমেদ নয়ন।। কৌশিক দাস।। তমোঘ্ন মুখার্জী।। গৌরাঙ্গ মন্ডল।। সঙ্গীতা মাইতি।। প্রগতি বৈরাগী একতারা।। রিম্পা নাথ।। সোমা কুন্ডূ (জারা সোমা)
        </h6><br><br><br><br>

        <h4 style="color:violet;"> অন্যভুবন
        </h4>

        <h6 >
          মৃণাল বসু চৌধুরী ।।  চৈতালী ব্রহ্ম।</h6><br><br><br><br>

          <h4 style="color:violet;"> অন্যভুবন
          </h4>

          <h6 >
            
কুসুম পাতার গান – বাদাম পাতার গল্প<br>

ভাঙা পেণ্ডউলামের শহরে ও রৌরবের স্নানাগারে<br>

চয়ন সমাদ্দার</h6><br><br><br><br><br>


  </p>
    </div>
  </div>

<!--
          <div id="childstory" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc1()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
          <div id="childstory1" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc2()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
          <div id="childstory2" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc3()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
          <div id="childstory3" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc4()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
          <div id="childstory4" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc5()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
          <div id="childstory5" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc6()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
         
          <div id="childstory6" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc7()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          <div id="childstory7" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc8()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          <div id="childstory8" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc9()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          <div id="childstory9" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc10()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          <div id="childstory10" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc11()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
         
          

         
         <div class="card-deck" style="margin-top: 50px;cursor: pointer;  margin-right: 0px;">
            <div class="flip-card" style="Margin-left: 50px; text-align: center; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer" id="childstory" onclick="openNavc1()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              
            <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer" id="childstory1" onclick="openNavc2()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer" id="childstory2" onclick="openNavc3()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
         <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer" id="childstory3"  onclick="openNavc4()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory4"  onclick="openNavc5()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory5"  onclick="openNavc6()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory6"  onclick="openNavc7()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory7"  onclick="openNavc8()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory8"  onclick="openNavc9()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory9"  onclick="openNavc10()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory10"  onclick="openNavc11()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
          
       
        </div>
    </div>-->

   
         <script src="css/navbar.css"></script>
         <script src="css/card.css"></script>
         <script src="javascript/navbar.min.js"></script>
 </body>
 </html>     