<!DOCTYPE html>
 <html lang="en">
 <head>
     <style>
     #spl {
  
  border:2px solid #fff;
  background: url(img/tiger.png) no-repeat;
  -moz-box-shadow: 10px 10px 5px #ccc;
  -webkit-box-shadow: 10px 10px 5px #ccc;
  box-shadow: 10px 10px 5px #ccc;
  -moz-border-radius:25px;
  -webkit-border-radius:25px;
  border-radius:25px;
}
</style>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title> সম্পাদকমণ্ডলী</title>
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
     <script src="https://kit.fontawesome.com/yourcode.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="../lib/w3.css">
     <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
     <link rel="stylesheet" href="css/navbar.css">
     <link rel="stylesheet" href="css/card.css">
     <link rel="stylesheet" href="css/signin.css">
     <link rel="stylesheet" href="css/footer.css">
     <link rel="stylesheet" href="css/dropdown.css">
     <link rel="stylesheet" href="css/popup.css">


 </head>
 <style>




 </style>
 <body  style=" background-image: url('img/b.jpg');
 background-size: cover;overflow-x: hidden;">
  <button onclick="topFunction()" id="myBtn" title="Go to top" style="color: white;"><i class="fa fa-arrow-up" aria-hidden="true"></i></button>

 
<div style="margin-left: 25px; margin-top :10px;">
        <center>
          <a href="index.php"class="active" style="background-color: transparent;"><img id="spl" src="img/KOsitebanne3r.png" height="auto" width="80%" ></a>

         
          <div id="mySidenav" class="sidenav" >
            <a href="javascript:void(0)" class="closebtn" onclick="CloseNav()">&times;</a>
          
            <a href="#" class=" nav-link " style="font-size: 16px;"><strong>আত্মপ্রকাশ সংখ্যা</strong></a> </li>
            <a href="bookfair.php" class= "nav-link"style="font-size: 16px;"><strong>বইমেলা সংখ্যা – ২০২০</strong></a> </li>
            <a href="sompadok.php" class="nav-link"style="font-size: 16px;"><strong>সম্পাদকীয়</strong></a></li>
            <a href="ahoron.php" class=" nav-link"style="font-size: 16px;" ><strong>আহরণ</strong></a></li>
            <a href="rupantor.php" class="nav-link "style="font-size: 16px;"><strong>রূপান্তর</strong></a></li>
            <a href="kandari.php " class=" nav-link "style="font-size: 16px;"><strong>কান্ডারী</strong></a></li>
            <a href="pothikrit.php" class=" nav-link "style="font-size: 16px;"><strong>পথিকৃৎ</strong></a></li>
            <a href="notundisha.php" class=" nav-link "style="font-size: 16px;"><strong>নতুন দিশা</strong></a></li>
            
            <a href="onnovubhan.php " class=" nav-link "style="font-size: 16px;"><strong>অন্যভুবন</strong></a></li>
            <a href="protibimbo.php" class=" nav-link "style="font-size: 16px;"><strong>প্রতিবিম্ব</strong></a></li>
             
       </div>

      <div class="ex1" style="float: right;">
         <span style="font-size:20px;cursor:pointer;" onclick="OpenNav()"><strong>Menu</strong></span>
          <a class="nav-item nav-link" style="color:black;margin-top: 10px;" href="signin.php" >
            <i class="w3-jumbo w3-spin  fa fa-user-circle fa-2x" aria-hidden="true" font-size="20px" ></i></a>
      </div>
    </div>        
        <br>

<h2 style="display:inline;text-shadow: 2px 2px grey;">&nbsp;&nbsp;<strong> সম্পাদকমণ্ডলী</strong></h2>&nbsp;&nbsp;
<img src="img/zs.png" style="display: inline;width: 90px; height: 70px;margin-bottom: 5px;">
<div class= "container" style="padding: 20px 30px; word-spacing: 1em;">
  <div class="p1" style="background-color: black;
  margin: 20px;
  color: white;
  font-weight: 15px;
  width: 80%px;
  border: 5px red solid;
  padding-left:  10px;
  opacity: 90%;
  border-width: 13px;
  border-style: dashed;
  border-color: rgb(195, 206, 195);
  margin-top: 20px;
  margin-left: 50px;
  margin-bottom: 20px;"
  >

    
<h3 style="color: yellow; font-size: 20px; text-align: center;">সম্পাদনা</h3>
<p>
<h7 style="color: violet ">উপদেষ্টা মন্ডলী</h7><br><br>
<h7 style="color:white ">কমল দে সিকদার || সব্যসাচী দেব || কৃষ্ণা বসু || সৈয়দ হাসমত জালাল</h7><br><br><br><br>

<h7 style="color: violet ">সভাপতি</h7><br><br>
<h7 style="color:white ">
  নারায়ণ বিশ্বাস</h7><br><br><br><br>

<h7 style="color: violet ">প্রধান সম্পাদক</h7><br><br>
<h7 style="color:white "> বৈজয়ন্ত রাহা</h7><br><br><br><br>

<h7 style="color: violet ">সহ সম্পাদক বৃন্দ</h7><br><br>
<h7 style="color:white ">কৌশিক চক্রবর্তী || পিনাকী দত্তগুপ্ত || নন্দিনী সেনগুপ্ত || অনুপম দাস অধিকারী || কাকলি দাশ ব্যানার্জী || রাহুল গুহ || অয়ন দাস || জয়ন্ত চট্টোপাধ্যায় || শ্রীমন্ত সেন || সঞ্চিতা কর || স্বাগতা পাল || পিয়াংকী মুখার্জী || মৈত্রেয়ী ঘোষ || অদিতি সেনগুপ্ত || শর্মিষ্ঠা দত্ত || সৌরভ বটব্যাল</h7><br><br><br><br>

<h7 style="color: violet ">প্রচ্ছদ চিত্র</h7><br><br>
<h7 style="color:white "> সৌরভ মিত্র</h7><br><br><br><br>


<h7 style="color: violet ">অলংকরণ </h7><br><br>
<h7 style="color:white ">অনুপম </h7><br><br><br><br>


<h5   style="color: yellow; font-weight: bold; text-align: center;">
  পা  ঠ  ক   স  মী  পে  ষু</h5><br><br><br>
  <h7>“যত মত তত পথ” । এক একজন সম্পাদক এক এক ভাবে তাঁর পত্রিকার অভিমুখ ও রূপরেখা তৈরি করেন। আমরা যেহেতু কবিতার উপরেই আমাদের আলোকবর্তিকা ফেলেছি তাই সমগ্র ভারত থেকে কবিতা ও তার বিবর্তনে আমরা আগ্রহী। এর মধ্যে যেমন ভারতবর্ষের অন্য রাজ্যও আছে, আছে তেমন পশ্চিমবঙ্গের প্রান্তিক স্থানও। আমরা মনে করিনা, যা কিছু লিখলেই তা কবিতা হয়ে যায়। কবিতার কিছু নিজস্ব ধর্ম আছে। কবির তা জানা প্রয়োজন।<br><br>
    এও আমরা মনে করিনা, উনিশশো চল্লিশে যে পরিভাষায় কবিতা লেখা হত, দু হাজার কুড়িতে সেই পরিভাষায় কবিতা লিখিত হলে কবিতা হিসেবে তা মান্যতা পাবে। কবিতাকে আমরা যেমন পরিষ্কার স্লোগান হিসেবে মান্যতা দিই না, তেমন দিই না বিবৃতি হিসেবেও। <br><br>
    আমরা ঘোষণা করতে চাই, সৌন্দর্যই কবিতার মূল গঠন বৈশিষ্ট্যের ধর্ম এবং তার সাথে বক্তব্য। বক্তব্য একজন গদ্য আকারে, প্রবন্ধ আকারে, প্রকাশ করতেই পারেন। কিন্তু তা কী কবিতা হবে? আমাদের দৃষ্টিভঙ্গীতে – না, হবে না। কবিতাকে কবিতার মতো হয়ে উঠতে হবে।<br><br><br><br>

 

    বহু স্বর শোনা যায়, ‘ কোনটা কবিতা , কোনটা নয় , তা কে ঠিক করে দেবেন? ‘ সেই কাজটাই করতে নেমেছে ‘কবিতার আলো’। স্বকালকে , স্বকালের যন্ত্রণা , অসহায়ত্ব, বিপন্নতা, রাজনৈতিক অস্থিরতা, আত্মকেন্দ্রিকতা,প্রেমহীনতাকে আমরা তুলে আনতে চাই দলিলের মতো এবং তা কবিতায়। যাতে আজ থেকে বহুকাল পরেও আমাদের এই সংখ্যা পড়ে একজন পাঠক চিনে নিতে পারেন এই  সময়কে।  বুঝে নিতে পারেন , কবিতার যাত্রাপথে , ঠিক এই সময়ে দাঁড়িয়ে কবিতা কেমন ছিল?<br><br><br><br>



    পাঠক অক্ষরলিপি পড়বেন? কাগজে কালিতে? যেখানে আন্তর্জালে এভাবে লেখা পড়ে নেওয়া যায়? হ্যাঁ, পড়বেন। যদি সেরকম লেখা হয়। আর একই লেখা যাতে সারা বিশ্ব পড়তে পারে, তাইতো এই ওয়েব ম্যাগাজিন।<br><br><br><br>



    মান কখনও বৃথা যায় না, এ আমাদের বিশ্বাস। আমরা জানি, ১৯৯৯ তে ইন্টারনেট আসার পর সারা বিশ্বে বিপ্লব হয়েছে। হয়েছে সাহিত্যক্ষেত্রেও। ছাপার অক্ষরে লেখা বিপন্নতার সম্মুখীন হয়েছে । কিন্তু না, এ বিপন্নতা নয়, বিজ্ঞানের অগ্রগতিকে মাথায় রেখেই পাশাপাশি অন্য মাধ্যমের প্রতিযোগিতাকে সঙ্গে করেই রূপরেখা নির্মাণ করবে ‘কবিতার আলো’।<br><br><br><br>



    সম্পাদক হিসেবে একটি ছোট দায়িত্ব পালন করতেই হয়। ধরুন একটি জলাধার সামনে। আপনি পিপাসার্ত। কিন্তু জলাধারের গায়ে এত অসামান্য কারুকাজ সেটা দেখতেই আপনার সময় পেরিয়ে গেল। ঢাকনা খুলে জল খাওয়া আর হল না। আবার ধরুন, একটি জলাধার। অতি সাধারণ। আপনি পিপাসার্ত, দৌড়ে এসে ঢাকনা খুললেন।  ভিতরে জল। একটু নীচে। আপনি ভিতরে, আরও ভিতরে হাত ঢোকাচ্ছেন , জল তুলবেন বলে। ধীরে , আপনার তৃষ্ণা আপনাকে অতলে নামিয়ে দিল। কবিতা হবে দ্বিতীয় প্রকার।  গভীরে , আরও গভীরে টেনে নিয়ে যাবে আপনাকে । আপনি প্রকৃত কবিতার স্বাদ পাবেন।<br><br><br><br>
    <h6 style="text-align: center; font-weight: bold;">  ধন্যবাদান্তে,  বৈজয়ন্ত রাহা</h6>
</h7>

    
  </p>
    </div>
  </div>

<!--
          <div id="childstory" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc1()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
          <div id="childstory1" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc2()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
          <div id="childstory2" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc3()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
          <div id="childstory3" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc4()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
          <div id="childstory4" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc5()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
          <div id="childstory5" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc6()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
         
          <div id="childstory6" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc7()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          <div id="childstory7" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc8()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          <div id="childstory8" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc9()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          <div id="childstory9" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc10()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          <div id="childstory10" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNavc11()">&times;</a>
            <div class="overlay-content">
              <a href="#" style="font-size: 18px;">Title,&nbsp;&nbsp;&nbsp;&nbsp;Author&nbsp;&nbsp;|&nbsp;&nbsp; Published Date</a>
              <a href="#" style="font-size: 14px;word-wrap: break-word;">story</a>
             
            </div>
          </div>
          
         
          

         
         <div class="card-deck" style="margin-top: 50px;cursor: pointer;  margin-right: 0px;">
            <div class="flip-card" style="Margin-left: 50px; text-align: center; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer" id="childstory" onclick="openNavc1()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              
            <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer" id="childstory1" onclick="openNavc2()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer" id="childstory2" onclick="openNavc3()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
         <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer" id="childstory3"  onclick="openNavc4()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory4"  onclick="openNavc5()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory5"  onclick="openNavc6()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory6"  onclick="openNavc7()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory7"  onclick="openNavc8()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory8"  onclick="openNavc9()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory9"  onclick="openNavc10()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
              <div class="flip-card" style="Margin-left: 50px; text-align: center ; margin-top: 30px;">
                <div class="flip-card-inner">
                  <div class="flip-card-front">
                    <h3 style="margin-top: 30px;">Title</h3>
                  </div>
                  <div class="flip-card-back">
                    <h5>Title</h5> 
                    <p>Date</p>
                    <span style="font-size:30px;cursor:pointer"id="childstory10"  onclick="openNavc11()"> <button style=" background: grey; border: none; padding: 10px; color: white; width: 40%; border-radius: 25px;font-size: 20px;">Read</button></span>
                  </div>
                </div>
              </div>
          
       
        </div>
    </div>-->

   
         <script src="css/navbar.css"></script>
         <script src="css/card.css"></script>
         <script src="javascript/navbar.min.js"></script>
 </body>
 </html>     