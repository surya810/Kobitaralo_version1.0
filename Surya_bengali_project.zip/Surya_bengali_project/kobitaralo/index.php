<!DOCTYPE html>
<html lang="en">

<head>
    <style>
    #spl {

        border: 2px solid #fff;
        background: url(img/tiger.png) no-repeat;
        -moz-box-shadow: 10px 10px 5px #ccc;
        -webkit-box-shadow: 10px 10px 5px #ccc;
        box-shadow: 10px 10px 5px #ccc;
        -moz-border-radius: 25px;
        -webkit-border-radius: 25px;
        border-radius: 25px;
    }
    </style>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>কবিতার আলো</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/yourcode.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../lib/w3.css">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/navbar.css">
    <link rel="stylesheet" href="css/card.css">
    <link rel="stylesheet" href="css/signin.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/slider.css">


</head>
<style>




</style>

<body style=" background-image: url('img/b.jpg'); background-size: cover; overflow-x: hidden;">
    <button onclick="topFunction()" id="myBtn" title="Go to top" style="color: white;">
        <i class="fa fa-arrow-up" aria-hidden="true"></i></button>


    <div style="margin-left: 25px; margin-top :10px;">
        <center>
            <a href="index.php" class="active" style="background-color: transparent;">

                <img id="spl" src="img/KOsitebanne3r.png" height="auto" width="80%"></a>


            <div id="mySidenav" class="sidenav">
                <a href="javascript:void(0)" class="closebtn" onclick="CloseNav()">&times;</a>

                <a href="#" class=" nav-link " style="font-size: 16px;"><strong>আত্মপ্রকাশ সংখ্যা</strong></a> </li>
                <a href="bookfair.php" class="nav-link" style="font-size: 16px;"><strong>বইমেলা সংখ্যা –
                        ২০২০</strong></a> </li>
                <a href="sompadok.php" class="nav-link" style="font-size: 16px;"><strong>সম্পাদকীয়</strong></a></li>
                <a href="ahoron.php" class=" nav-link" style="font-size: 16px;"><strong>আহরণ</strong></a></li>
                <a href="rupantor.php" class="nav-link " style="font-size: 16px;"><strong>রূপান্তর</strong></a></li>
                <a href="kandari.php " class=" nav-link " style="font-size: 16px;"><strong>কান্ডারী</strong></a></li>
                <a href="pothikrit.php" class=" nav-link " style="font-size: 16px;"><strong>পথিকৃৎ</strong></a>
                </li>
                <a href="notundisha.php" class=" nav-link " style="font-size: 16px;"><strong>নতুন দিশা</strong></a></li>

                <a href="onnovubhan.php " class=" nav-link " style="font-size: 16px;"><strong>অন্যভুবন</strong></a></li>
                <a href="protibimbo.php" class=" nav-link " style="font-size: 16px;"><strong>প্রতিবিম্ব</strong></a></li>

            </div>

            <div class="ex1" style="float: right;">
                <span style="font-size:20px;cursor:pointer;" onclick="OpenNav()"><strong>Menu</strong></span>
                <a class="nav-item nav-link" style="color:black;margin-top: 10px;" href="signin.php">
                    <i class="w3-jumbo w3-spin  fa fa-user-circle fa-2x" aria-hidden="true" font-size="20px"></i></a>
            </div>

    </div>
    </div>
    <br><br><br>

    <div style="background-color:transparent; margin: auto; text-align: center; ">
        <!-- Start cssSlider.com -->



        <div id="spl" class='csslider1 autoplay ' style="width: 80%;" border=5>
            <input name="cs_anchor1" id='cs_slide1_0' type="radio" class='cs_anchor slide'>
            <input name="cs_anchor1" id='cs_slide1_1' type="radio" class='cs_anchor slide'>
            <input name="cs_anchor1" id='cs_slide1_2' type="radio" class='cs_anchor slide'>
            <input name="cs_anchor1" id='cs_play1' type="radio" class='cs_anchor' checked>
            <input name="cs_anchor1" id='cs_pause1' type="radio" class='cs_anchor'>
            <ul>
                <div style="width: 100%; visibility: hidden; font-size: 0px; line-height: 0;">
                    <img src="http://cssslider.com/sliders/pen/images/buns.jpg" style="width: 100%;">
                </div>
                <li class='num0 img'>
                    <a target=""><img src='img/d.jpg' style="width:100%; height: 100%;" /> </a>
                </li>

                <li class='num1 img'>
                    <a target=""><img src='img/c.jpg' style="width:100%; height: 100%;" /> </a>
                </li>

                <li class='num2 img'>
                    <a target=""><img src='img/xyz.jpg' style="width:100%; height: 100%;" /> </a>
                </li>



            </ul>


            <div class='cs_arrowprev'>
                <label class='num0' for='cs_slide1_0'
                    style="text-align: center;font-size: 40px;"><strong>&#10094;</strong></label>
                <label class='num1' for='cs_slide1_1'
                    style="text-align: center;font-size: 40px;"><strong>&#10094;</strong></label>
                <label class='num2' for='cs_slide1_2'
                    style="text-align: center;font-size: 40px;"><strong>&#10094;</strong></label>
            </div>
            <div class='cs_arrownext'>
                <label class='num0' for='cs_slide1_0'
                    style="text-align: center;font-size: 40px;"><strong>&#10095;</strong></label>
                <label class='num1' for='cs_slide1_1'
                    style="text-align: center;font-size: 40px;"><strong>&#10095;</strong></label>
                <label class='num2' for='cs_slide1_2'
                    style="text-align: center;font-size: 40px;"><strong>&#10095;</strong></label>
            </div>

            <div class='cs_bullets'>
                <label class='num0' for='cs_slide1_0'>
                    <span class='cs_point'></span>
                    <span class='cs_thumb'><img src='img/d.jpg' style="width:100%; height: 400px;" /></span>
                </label>
                <label class='num1' for='cs_slide1_1'>
                    <span class='cs_point'></span>
                    <span class='cs_thumb'><img src='img/c.jpg' style="width:100%; height: 380px;" /></span>
                </label>
                <label class='num2' for='cs_slide1_2'>
                    <span class='cs_point'></span>
                    <span class='cs_thumb'> <img src='img/xyz.jpg' style="width:100%; height: 380px;" /></span>

                </label>

            </div>
        </div>

        <div class="card-deck" style="margin-top: 100px;cursor: pointer; ">
            <div id="spl" class="card" style="Margin-left: 30px; margin-right: 30px; text-align: center;">
                <button id="spl" class="button2" style="border:0ch;">
                    <a style="color: black;text-decoration:none;" href="sompadok.php">
                        <div class="card1">
                            <div class="card-body" style="padding-left:10px; padding-right:10px;height: 100px;">
                                <h5 class="card-title" style="text-align:center; font-size: 18px;">কবিতার আলো<br><br>
                                </h5>
                            </div>
                        </div>
                    </a>
                </button>
            </div>

            <div id="spl" class="card" style="Margin-left: 30px;margin-right: 30px;text-align: center; ">
                <button id="spl" class="button2" style="border:0ch;height: 100px;">
                    <a style="color: black;text-decoration:none ;" href="ahoron.php">
                        <div class="card1">
                            <div class="card-body">
                                <h5 class="card-title">আহরণ <br><br></h5>
                            </div>
                        </div>
                    </a>
                </button>
            </div>

            <div id="spl" class="card" style="Margin-left: 30px;margin-right: 30px; text-align: center; ">
                <button id="spl" class="button2" style="border:0ch; height: 100px;">
                    <a style="color: black;text-decoration:none ;" href="rupantor.php">
                        <div class="card1">
                            <div class="card-body">
                                <h5 class="card-title">রূপান্তর <br> <br></h5>
                            </div>
                        </div>
                    </a>
                </button>
            </div>

            <div id="spl" class="card" style="Margin-left: 30px;margin-right: 30px;text-align: center ;">
                <button id="spl" class="button2" style="border:0ch;height: 100px;">
                    <a style="color: black;text-decoration:none;" href="kandari.php">
                        <div class="card1">
                            <div class="card-body">
                                <h5 class="card-title">কান্ডারী <br><br></h5>
                            </div>
                        </div>
                    </a>
                </button>
            </div>

            <div id="spl" class="card" style="Margin-left: 30px;margin-right: 30px;text-align: center; ">
                <button id="spl" class="button2" style="border:0ch;">
                    <a style="color: black;text-decoration:none ;" href="pothikrit.php">
                        <div class="card1">
                            <div class="card-body">
                                <h5 class="card-title">পথিকৃৎ <br><br></h5>
                            </div>
                        </div>
                    </a>
                </button>
            </div>

            <div id="spl" class="card" style="Margin-left: 30px;margin-right: 30px; text-align: center; ">
                <button id="spl" class="button2" style="border:0ch; height: 100px;">
                    <a style="color: black;text-decoration:none ;" href="notundisha.php">
                        <div class="card1">
                            <div class="card-body">
                                <h5 class="card-title">নতুন দিশা </h5>
                            </div>
                        </div>
                    </a>
                </button>
            </div>

            <div id="spl" class="card" style="Margin-left: 30px;margin-right: 30px; text-align: center; ">
                <button id="spl" class="button2" style="border:0ch; height: 100px;">
                    <a style="color: black; text-decoration:none ;" href="onnovubhan.php" style="margin-right:10px;">
                        <div class="card1">
                            <div class="card-body" style="padding-left:10px; padding-right:10px">
                                <h5 class="card-title" style="text-align:center; font-size: 20px;">অন্যভুবন <br><br>
                                </h5>
                            </div>
                        </div>
                    </a>
                </button>
            </div>


            <div id="spl" class="card" style="Margin-left: 30px;margin-right: 30px;text-align: center; ">
                <button id="spl" class="button2" style="border:0ch;height: 100px;">
                    <a style="color: black;text-decoration:none ;" href="protibimbo.php">
                        <div class="card1">
                            <div class="card-body">
                                <h5 class="card-title">প্রতিবিম্ব <br><br></h5>
                            </div>
                        </div>
                    </a>
                </button>
            </div>






        </div>










        <footer class="page-footer font-small  pt-4"
            style="background-color:rgb(53, 50, 50);color: white;margin-top: 10%;">


            <div class="container text-center text-md-4">


                <div class="row">


                    <div class="col-md-2 mx-auto">


                        <h5 style="text-align: center;"><strong>FOLLOW US</strong></h5>
                        <!-- Social buttons -->
                        <ul class="list-unstyled list-inline text-center">
                            <li class="list-inline-item">
                                <a href="https://www.facebook.com/%E0%A6%95%E0%A6%AC%E0%A6%BF%E0%A6%A4%E0%A6%BE%E0%A6%B0-%E0%A6%86%E0%A6%B2%E0%A7%8B-111704297078497/"
                                    class="fa1  fa fa-facebook text-center"></a>

                            </li>
                            <li class="list-inline-item">
                                <a href="https://www.youtube.com/channel/UCdZbIh93dQ3DDFVShxQYa8w"
                                    class="fa1 fa fa-youtube text-center"></a>
                            </li>


                        </ul>

                    </div>
                    <br>


                    <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4" id="text">
                        <center>
                            
                            <h5 class="text-uppercase font-weight-bold" id="con">Contact</h5>

                            <p style="cursor: pointer;text-align: center;width: 265px;margin-bottom: 10px;">
                                <i class="fa fa-home fa-lg mr-1" aria-hidden="true"></i><b>Address</b><br>Manicktala
                                Housing Estate, Block -V,Flat -5, V.I.P Road, Kolkata - 700054
                            </p>
                            <div>

                            <p style="cursor: pointer;text-align: center;width: 265px;margin-bottom: 10px;">
                                <i class="fa fa-envelope mr-1"></i><b>Email&nbsp;&nbsp;&nbsp;
                                </b>kobitapatro19@gmail.com
                            </p>
                            </div>
                            <p style="cursor: pointer;text-align: center;width: 265px;margin-bottom: 10px;">
                                <i class="fa fa-phone fa-lg mr-1" aria-hidden="true"></i><b>Mob.
                                    No.</b>&nbsp;&nbsp;+91-9831605881
                            </p>

                        </center>
                    </div>

                   <!--  comment  -->
                    <hr class="clearfix w-100 d-md-none">
                    <div class="col-md-2 mx-auto">
                    <i class= "fa fa-users"></i>
                        <h5 class="font-weight-bold text-uppercase" style="margin-top: 0px; margin-bottom: 8px;">
                            Powered By</h5>
                            <h6 style="font-style: italic;  color: red; text-shadow: 2px 2px 4px 6px; font-weight:bold;"> <span>K.Chakraborty</span>
                            <br>
                             <span> & </span>
                             <br>

                            <span> S.Das</span></h6>


                    </div> 
                    <!-- Grid column -->

    </div>
     <!-- Grid row -->

 </div>
                <!-- Footer Links -->
</footer>
        <!-- Footer -->
       <style>
            @media screen and (max-height: 600px)
              {

                 #text h5 {
                    margin-top: 25px;
                   
                 }

                }
       </style>
  



        <script src="css/navbar.css"></script>
        <script src="css/card.css"></script>
        <script src="javascript/navbar.min.js"></script>
</body>

</html>